from autochart.printplus import *

from autochart.noteobj import *
from autochart.inout import *
from autochart.inpnote import *

import argparse

parser = argparse.ArgumentParser()

parser.add_argument('-i', '--input_file', help = 'File to use as input', 
    default = 'input.txt')
parser.add_argument('-o', '--output_file', help = 'File to use as output', default = 'output.txt')
parser.add_argument('-j', '--inject_file', help = 'File to inject to (must be ssc)', default = None)
parser.add_argument('-m', '--meter', help = 'Meter of the injected chart', default = None,
    type = int)
parser.add_argument('-p', '--pdb', help = 'Use pdb', action = 'store_true')

args = parser.parse_args()

if args.pdb: pdb.set_trace()

if args.inject_file:
    injectSSCToChart(args.input_file, args.inject_file, args.meter)
else:
    convertToSSC(args.input_file, args.output_file)